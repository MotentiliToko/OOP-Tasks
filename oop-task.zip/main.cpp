#include <iostream>

using namespace std;
class rectangle {
    private:
        int length;
        int width;
        int perimeter = length + width;
        
    public:
        int getLength() {
            return length;
        }
        void setLength(int newLength) {
            length = newLength;
        }
        int getWidth() {
            return width;
        }
        void setWidth(int newWidth) {
            width = newWidth;
        }
        
        int getPerimeter() {
            return 2 *(width + length);
        }
};
int main()

{
    rectangle Rec;
    Rec.setWidth(15);
    Rec.setLength(25);
    cout << Rec.getWidth() << endl;
    cout << Rec.getLength() << endl;
    cout << Rec.getPerimeter() << endl;
    
    return 0;
}
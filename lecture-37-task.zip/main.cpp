#include <iostream>

using namespace std;
class Manufacturer {
    public:
        string Name;
        int Numofmanufacturedcars;
        void getDescription() {
            cout << "The name of manufacturer is: " << Name << endl;
            cout << "The number of manufactured cars is: "  << Numofmanufacturedcars << endl;
        }
};

class Car: public Manufacturer {
    public:
        string Name;
        string Color;
        int Price;
        int MaxSpeed;
        bool Drivable;
        bool RearCamera;
        bool SeatHeating;
        void getDescription() {
            cout << "The name of the car is: " << Name << endl;
            cout << "The car is " << Color << endl;
            cout << "The price of the car is: " << Price << endl;
            cout << "Maximum speed of the car is: " << MaxSpeed << endl;
        }
};

class Country: public Car {
    public:
        string Name;
        int SoldCars;
        bool Port;
        void getDescription() {
            cout << "The name of the country is: " << Name << endl;
            cout << "The number of the sold cars is: " << SoldCars << endl;
        }
};
int main()
{
    Manufacturer brand;
    brand.Name = "Mercedes-Benz";
    brand.Numofmanufacturedcars = 1000;
    brand.getDescription();
    Car car;
    car.Name = "E 350";
    car.Color = "Black";
    car.Price = 18000;
    car.MaxSpeed = 240;
    car.Drivable = true;
    car.RearCamera = true;
    car.SeatHeating = true;
    car.getDescription();
    Country country;
    country.Name = "America";
    country.SoldCars = 25000;
    country.Port = true;
    country.getDescription();

    return 0;
}